# -*- coding: utf-8 -*-
"""
Created on Wed Nov 22 19:52:36 2017

默认参数：
    错误率：30%
    人参与率：20%  人判断20%的更新数据
    初始训练集大小：3000

@author: guoky11
"""

import pandas as pd
import numpy as np
import math
import pickle as pi
import time
import sys
import string
from operator import itemgetter
import Levenshtein
#import networkx as nx
import matplotlib.pyplot as plt
import os
import copy

plt.rcParams['font.sans-serif']=['SimHei'] #用来正常显示中文标签
plt.rcParams['axes.unicode_minus']=False #用来正常显示负号


def load_data(file_path):
    """导入csv数据,输出array类型"""
#    data = pd.read_csv(file_path, header=None,dtype='str')
    data = pd.read_csv(file_path, header=None)
    data = np.array(data)
    
    return data

def divide_XY(data, features, labels):
    """划分特征属性和类别属性
    ：features为特征属性列号，list类型
    ：lables为类别属性列号，list类型
    :返回特征属性对应数据X,类别属性对应数据Y
    """
    X = data[:, features]
    Y = data[:, labels]
    
    return X, Y


class BayesClassical(object):
    """贝叶斯分类器"""
    def parameter(self, X, Y=None, continuous=None):
        """求训练集各参数"""
        # 参数X初始化
        self.lanmda = 1  # 平滑参数,“1”:为拉普拉斯平滑
        self.X_unique = []  # 特征属性去重
        self.X_count=[]  # 特征属性非重复值个数
        self.X_num = X.shape[1]  # 特征属性列数
        self.X_length = X.shape[0]  # 特征属性数据行数
        # 统计特征属性数据各参数
        for i in range(self.X_num):
            if i in continuous:
                self.X_unique.append([])
                self.X_count.append([])  # 统计异值个数
            else:
                self.X_unique.append(list(np.unique(X[:, i])))
                self.X_count.append(len(self.X_unique[i]))  # 统计异值个数
        # 统计类别属性数据各参数
        if Y is not None:
            self.Y_unique = np.unique(Y)  # 分类属性去重
            self.Y_count = len(self.Y_unique)  # 分类属性非重复值个数
            self.Y_length = Y.shape[0]  # 类别属性数据行数
        # 确定连续型的列
        if continuous is None:
            self.continuous = list(range(len(X[0])))
        else:
            self.continuous = continuous
            
    def parameter2(self, features, labels):
        """原始数据参数"""
        self.features_num = len(features)
        self.labels_num = len(labels)
        self.features = features
        self.labels = labels
        
    def bayes_model(self, X, Y, continuous=None):
        """训练高斯贝叶斯模型
        ：对连续型数据：不能直接求条件概率P(y)，只保存求正太分布概率密度（也就是P(y)）需要的均值和方差
        ：划分后，当前数据块求得方差为0，#使得后验概率计算出现分母为0情况，这里考虑可能会出现其他数值，给一个非0方差。
            同时考虑这个划分中数值个数，数值越多，方差越小，表示出现其他数值概率更小
        """
        if len(Y[0]) != 1:
            print("类别属性列数需为1")
            sys.exit(1)
        # 求参数
        self.parameter(X, Y=Y, continuous=continuous)
        # 求概率
        P_y = {}  # 类型：字典；存储类别属性先验概率P(y)
        P_xy = {}  # 类型：字典；存储条件概率P(x|y)
        self.y_count = {}  # 类型：字典；存储类别属性以某个值划分的数据的行数
        for y in self.Y_unique:
            # 求类别属性的先验概率:P(y)
            Y = list(Y)  # 便于应用list的count()方法
            self.y_count[y] = Y.count(y)     # y在labels中出现的次数
            P_y[y] = (self.y_count[y] + self.lanmda) / \
                     (self.Y_length + self.lanmda * self.Y_count)  # 贝叶斯估计计算类别属性先验概率       
            # 求条件概率:P(x|y)
            y_index = [i for i, j in enumerate(Y) if j == y]  # Y对于y的划分；表示为y在Y中的所有下标
            # 对每一列求条件概率
            for i in range(self.X_num):
                temp_dict = {}
#                a = 0
#                b = 0
#                c = 0
                # 处理连续型数据
                if i in self.continuous:
                    sum_ = 0
                    deviation_ = 0
                    for j in y_index:
                        sum_ += X[j, i]
                    mean_ = sum_ / self.y_count[y]
                    pkey_1 = 'mean|'+str(y)
                    temp_dict[pkey_1] = mean_  # 临时存储均值
                    for j in y_index:
                        temp_deviation = X[j, i] - mean_
                        deviation_ += temp_deviation * temp_deviation
                    if deviation_ != 0 :
                        var_ = deviation_ / (self.y_count[y]-1)  # 极大似然估计得到均值和方差参数     
                    else:
                        var_ = 1 / self.y_count[y]  # 方差为0的处理；详细见上。
                    pkey_2 = 'var|' + str(y)
                    temp_dict[pkey_2] = var_  # 临时存储方差
                else:
                    for j in self.X_unique[i]:
                        pkey_3 = str(j) + '|' + str(y)
                        xy_count = 0
                        for k in y_index:
                            if (X[k, i] == j):
                                xy_count += 1  # x,y同时出现的次数
                        temp_dict[pkey_3] = (xy_count + self.lanmda) / \
                                            (self.y_count[y] + self.lanmda * 
                                                  self.X_count[i])  # 贝叶斯估计得到条件概率
                        if(temp_dict[pkey_3] == 0):
                            print("%s:条件概率为0"%pkey_3)
#                        a += temp_dict[pkey_3]
#                        b += xy_count
#                        c += 1
#                print(i, a, b, y_count, c, self.X_count[i])
                if i in P_xy.keys():
                    P_xy[i].update(temp_dict)
                else:
                    P_xy[i] = temp_dict
                    
        return P_y, P_xy
    
    def save_model(self,P_y=None, P_xy=None, M=None, model_path=None):
        """模型存储
        :存储P(y),P(x|y),各参数
        :用pickle
        """
        #存储到地址            
        if M and model_path:
            f = open(model_path, "wb")
            pi.dump(M, f)
            f.close()
        else:
            #模型数据集成
            M = {}
            M['P_y'] = P_y
            M['P_xy'] = P_xy
            M['parameter'] = {}
            M['parameter']['X_unique'] = self.X_unique
            M['parameter']['X_count'] = self.X_count
            M['parameter']['X_num'] = self.X_num
            M['parameter']['X_length'] = self.X_length
            M['parameter']['Y_unique'] = self.Y_unique
            M['parameter']['Y_count'] = self.Y_count
            M['parameter']['Y_length'] = self.Y_length
            M['parameter']['continuous'] = self.continuous
            M['parameter']['y_count'] = self.y_count
            return M
        
    def load_model(self,model_path):
        """导入模型"""
        # 导入类别属性后验概率：P(y)
        f = open(model_path, "rb")
        M = pi.load(f)
        f.close()
        
        return M

    def classical_f(self, data, M=None, model_path=None):
        """分类预测
        ：计算后验概率P(y|x)=
        ：仅对一个元组/一行数据
        ：M,model_path: 模型数据;二选一;优先选择P
        """
        if not M:
            M = self.load_model(model_path)  # 若内存没有模型数据，则从路径导入
        # 模型数据导出
        P_y = M['P_y']  # 类别属性后验概率
        P_xy = M['P_xy']  # 条件概率
        P_parameter = M['parameter']  # 模型参数
        Y_unique = P_parameter['Y_unique']  # 类别属性非重复值
        X_num = P_parameter['X_num']
        y_count = P_parameter['y_count']
        continuous = P_parameter['continuous']
        # 矩阵转换
        data = np.mat(data)  # 可以处理单条数据；访问方法：data[i,j]
        # 计算后验概率P(y|x)
        P_yx = {}  # 存储后验概率P(y|x)
        P_xxy = {}  # 后验概率分子
        P_x = 0  #后验概率分母
        classical = {}  # 存储最终分类
        BvSB = {}
        for i in range(len(data)):  #每一行为一单位进行分类预测
            P_yx[i] = {}  #存储每一条数据的后验概率
            P_xxy[i] = {}  #存储每一条后验概率的分子
            for y in Y_unique:  #计算这一条数据到每一个类别属性值（标签）的概率
                temp_P_xxy = P_y[y]
                pkey = str(y) + '|' 
                for j in range(X_num):
                    if j in continuous:
                        # 计算连续型数据的条件概率
                        pkey_1 = "var|" + str(y)
                        pkey_2 = "mean|" + str(y)
                        temp_P_xy = 1 / \
                            math.sqrt(2 * math.pi * P_xy[j][pkey_1]) * \
                            math.exp(-(data[i,j] - P_xy[j][pkey_2]) ** 2 / 
                                        (2 * P_xy[j][pkey_1]))  # 正太分布概率密度公式
                    else:
                        # 计算离散型数据的条件概率
                        pkey_3 = str(data[i,j]) + '|' + str(y)
                        if pkey_3 in P_xy[j]:
                            temp_P_xy = P_xy[j][pkey_3]
                        else:
                            #对于不在模型中的特征属性数据，给予边缘化处理
                            temp_P_xy = 1 / (y_count[y] * 2)
#                        if temp_P_xy < Decimal(1)/Decimal(y_count[y] * 2):
#                            print(j, pkey_3, temp_P_xy, y_count[y])
                    temp_P_xxy *= temp_P_xy
                    pkey = pkey + str(data[i,j])
                P_xxy[i][pkey] = temp_P_xxy
                P_x += temp_P_xxy
            if P_x == 0:
                print("后验概率分母为0")
                P_x = 1e-323
            # 判断最终分类
            init_B = 0
            init_SB = 0
            for y in Y_unique:
                pkey_4 = str(y) + '|'
                temp_pkey = ''.join(map(str,np.array(data[i])[0]))
                pkey_4 = pkey_4 + temp_pkey
                if(P_xxy[i][pkey_4] > init_B):
                    temp_classical = y
                    init_B, init_SB = P_xxy[i][pkey_4], init_B
                else:
                    if(P_xxy[i][pkey_4] > init_SB):
                        init_SB = P_xxy[i][pkey_4]
                P_yx[i][pkey_4] = P_xxy[i][pkey_4] / P_x
            classical[i] = temp_classical
            BvSB[i] = (init_B - init_SB) / P_x
        return P_yx, classical, BvSB

class SCAREd(BayesClassical):
    """SCAREd方法"""
    def model_train(self,features,labels,data=None,data_path=None,model_path=None,continuous=None,certainty=0.7):
        """训练多类别属性的数据"""
        # 数据导入
        if data is None:
            if data_path is not None:
                data = load_data(data_path)
            else:
                print("没有数据")
                sys.exit()
        # 模型训练
        M = {}  # 保存不同列的模型
        features_ = features.copy()
        for i in labels:
            lable = [i]
            X, Y = divide_XY(data, features_, lable)
            P_y, P_xy = self.bayes_model(X, Y, continuous=continuous)
            M[i] = self.save_model(P_y, P_xy, model_path=model_path)
            features_.append(i)
        self.save_model(M=M,model_path=model_path)

        return M
    
    def get_predictions(self, M, labels, r, t, p, certainty, all_predictions, data_quality):
        """多类别属性分类
        :初始(模型集M,分类属性集合,特征属性(去分类属性下的值)，原始值(整行)，概率p=1.0,最终结果)
        """
#        print(r,type(r))
#        r = list(r)
#        print(r,type(r))
#        t = list(t)
        if len(labels) <= 0:  #训练完成
#            print(0)
            f_ = r[-self.labels_num:]  #存储当前的各分类属性的预测值
            if p == 0:
#                print("get_prections:后验概率为0")
                p = 1e-323  #后验概率溢出，赋予python可表示的最小值。求log不会出错
            p_log = math.log(p)
            all_predictions.append([f_, p, p_log, certainty])
            t_ = t[self.features]
            t_ = np.append(t_, t[self.labels])
            if (r == t_).all():  #标记未更改分类属性值求得的后验概率
                self.certainty_0 = certainty
#                if self.certainty_0 > 0.005526315789473684*0.21*0.21:
#                    print(self.certainty_0)
                self.p_0 = p
                self.p_log_0 = p_log
            return all_predictions
        else:
#            print(1)
            # 选择模型
            labels_ = labels.copy()
            k = labels_.pop(0)
            M_ = M[k]
            # 分类
            p_yx, classical, BvSB = self.classical_f(r, M=M_)
            # 计算下一层分类输入参数
            pkey = classical[0] + '|'
            for i in r:  #考虑原分类值不在训练模型中
                pkey += str(i)
            p_ = p * p_yx[0][pkey]
            #确定度归一化
            if classical[0] != t[k]:
                BvSB_ = certainty * BvSB[0]
            else:
                acc = data_quality
                err = (1 - acc) / (M_['parameter']['Y_count']-1)
                certainty_init = acc - err
                if certainty_init < 0.1**10:
                    certainty_init = 0.1**10
                if abs(acc - err) < BvSB[0]:
                    BvSB_ = certainty * BvSB[0]
                else:
                    BvSB_ = certainty * certainty_init               
            r_ = r.copy()
            r_ = np.append(r_, classical[0])
            self.get_predictions(M, labels_, r_, t, p_, BvSB_, all_predictions,data_quality)
            # 若分类不同，使原值参与下一层分类
            if classical[0] != t[k]:
#                print(2)
                p_ = p
                acc = data_quality
                err = (1 - acc) / (M_['parameter']['Y_count']-1)
                certainty_init = acc - err
                if certainty_init < 0.1**10:
                    certainty_init = 0.1**10
                BvSB_ = certainty
                r_ = r.copy()
                r_ = np.append(r_, t[k])
                pkey = str(t[k]) + '|'
                for i in r:  #考虑原分类值不在训练模型中
                    pkey += str(i)
                if t[k] not in M_['parameter']['Y_unique']:
#                    print('原分类值不在训练集中，第{}列值：{}'.format(k,t[k]))
                    p_ *= 1. / M_['parameter']['X_length']**len(r)
                    BvSB_ = 0.1**10
                else:
                    p_ = p * p_yx[0][pkey]
                    BvSB_ = certainty * certainty_init
                self.get_predictions(M, labels_, r_, t, p_, BvSB_, all_predictions,data_quality)
                
    def classify(self, M, labels, t, data_quality):
        """多分类属性最终分类结果"""
        self.parameter2(features, labels)  #求原始参数（特征属性列数，分类属性列数）
        # 初始参数赋值
        r = t[self.features]
        p = 1.0
        all_predictions = []
        certainty = 1.0
        self.get_predictions(M, labels, r, t, p, certainty, all_predictions, data_quality)
        # 筛选最高的收益成本比率
        lc = 0.0  #设置初始收益成本率，若log后验概率没有原始值高，收益为负，不符合标准，可直接排除。
        f = list(t[labels])
#        print(f)
        f = ''.join(f)
        flag = -1
#        print(self.p_log_0)
        
        for j in range(len(all_predictions)):
#            print(all_predictions[j])
            if all_predictions[j][2] > self.p_log_0:
                l = all_predictions[j][2] - self.p_log_0  #收益计算
                f_ = ''.join(all_predictions[j][0])
#                f_ = all_predictions[j][0]
#                c = 0
#                for i in range(len(f)):
#                    c += Levenshtein.distance(f[i],f_[i]) / max(len(f[i]), len(f_[i]))
                c = Levenshtein.distance(f,f_) / max(len(f), len(f_))  #成本计算
                if l/c > lc:
                    flag = j
                    lc = l/c
#                    print(all_predictions[j])
#                    print(flag,l,c,l/c)
        if flag == -1:
            classical_P = all_predictions[len(all_predictions)-1]  #若收益成本比率都小于
        else:
            classical_P = all_predictions[flag]
#        print(classical)
        lc = 0.0
        flag = -1
        for j in range(len(all_predictions)):
#            print(all_predictions[j])
            if all_predictions[j][3] > self.certainty_0:
                l = all_predictions[j][3] - self.certainty_0  #收益计算
                f_ = ''.join(all_predictions[j][0])
                c = Levenshtein.distance(f,f_) / max(len(f), len(f_))  #成本计算
#                c = 1
                if l/c > lc:
                    flag = j
                    lc = l/c
#                    print(all_predictions[j])
#                    print(flag,l,c,l/c)
        if flag == -1:
            classical_BvSB = all_predictions[len(all_predictions)-1]  #若收益成本比率都小于
        else:
            classical_BvSB = all_predictions[flag]
#        if classical_BvSB[3] < 0.5:
#            print()
        classical_BvSB[3] -= all_predictions[-1][3]
        return classical_P,classical_BvSB  #返回最大收益成本率的信息（预测值，后验概率，log后验概率）
    
    def classify2(self, M, labels, t):
        """使用图集成预测值"""
        G = nx.Graph()
        K_set = []
        for i in M.keys():
            j = [j for j in range(len(M[i]['block_values'])) if t[i] == M[i]['block_values'][j]]
#            print('{:5}{}'.format(i,j))
            j = j[0]
            M_ = M[i][j]
            classical = self.classify(M_, labels, t)
            classical[1] *= M[i][j]['reliability']
            G, K_set= self.Graph_build(G, classical, K_set)
        classical = self.Graph_K(G, K_set)
        
        return classical
    
    def classify_tuples(self, data, M, labels, SCAREd=None,data_quality=0.7):
        """对多条数据进行多分类属性的分类
        :SCAREd参数：a). None: 返回多列属性预测值
                    b). 0: 返回模型可靠度，此时data为训练集
                    c). 1: 返回图集成后的各列预测值，此时M为分块后训练的模型
        """            
        classical = []
        classical_P = []
        classical_BvSB = []
        for i in range(len(data)):
#            if i % 5000 == 0:
#                print('分类第{}条数据'.format(i))
#            if i == 20:
#                break
#            print(i)
            t = data[i]
            if SCAREd == 1:
#                classical.append(self.classify2(M, labels, t))
                result = self.classify2(M, labels, t)
            else:
#                classical.append(self.classify(M, labels, t))
                result_P,result_BvSB = self.classify(M,labels,t,data_quality)
            classical_P.append(result_P)
            classical_BvSB.append(result_BvSB)
        # SCAREd 模型可靠性计算
        if SCAREd == 0:
            loss_temp = 0
            for i in range(len(data)):
                f = list(data[i][labels])
                f = ''.join(f)
                f_ = classical[i][0]
                f_ = ''.join(f_)
                c = Levenshtein.distance(f,f_) / max(len(f), len(f_))  #成本计算
                loss_temp += c
            loss = loss_temp / len(data)
            return loss
        else:
            return classical_P,classical_BvSB
        
    def Graph_build(self, G, classical_, K_set):
        """K图的创建"""
        node_num = len(classical_[0])
        for i in range(node_num):
            a = classical_[0][i]
            if len(K_set) == i:
                K_set.append([a])
            else:
                if a not in K_set[i]:
                    K_set[i].append(a)
            if i == node_num - 1:
                break
            for j in range(i+1,node_num,1):
                b = classical_[0][j]
                if (a,b) in G.edges:
                    weight_new = G.edges[(a,b)]['weight'] + classical_[1]
                    count_new = G.edges[(a,b)]['count'] + 1
                    G.add_edge(a,b,weight = weight_new, count = count_new)
                else:
                    G.add_edge(a,b,weight = classical_[1], count = 1)
    
        return G, K_set
    
    def Graph_K(self, G, K_set):
        """K图的实现"""
#        print(G.number_of_nodes(),len(K_set))
        if G.number_of_nodes() == len(K_set):
            p = 0
            for i in G.edges:
                p += G.edges[i]['weight'] / G.edges[i]['count']
            p = p / len(K_set)
            if p == 0:
                print("后验概率为0")
                p = 1e-323
            p_log = math.log(p)
            classical_temp = []
            classical = []
            [classical_temp.append(i) for i in G.node.keys()]
            classical = [classical_temp, p, p_log]
            
            return classical
        
        else:
            list1 = []
            for i in range(len(K_set)):
                if len(K_set[i]) > 1:
                    for j in K_set[i]:
                        list1.append([j, G.degree(j, weight = 'weight'), i])
            list1 = sorted(list1, key = itemgetter(1))
            G.remove_node(list1[0][0])
            K_set[list1[0][-1]].remove(list1[0][0])
            
            return self.Graph_K(G, K_set)

    def model_train_block(self, features, labels, data_block=None, data_path=None, continuous=None):
        """训练多类别属性的各块数据
        :data:dict类型；
              索引： a.)每块数据，索引为块号[0,1,2...]。
                    b.)数据的各参数，索引为["block_count","block_values","block_length"]
                       分别为块个数，以哪个值作为划分数据，每一块数据的元组数。
        ：M：输出；
            dict类型；
            索引：一层索引：块名[0,1,2...]；
                 二层索引：a.)以各模型对应的分类属性列号[13,14,15...]
                         b.)模型可靠性["reliability"]
        """
        # 数据导入
        if data_block is None:
            if data_path is not None:
                data_block = load_data(data_path)
            else:
                print("没有数据")
                sys.exit()
        # 模型训练
        M = {}  # 保存不同划分方法的模型
        for k in data_block.keys():
#            k=3
            if data_block[k] != []:
                M[k] = {}  #保存第k个划分方法中不同块的模型
                block_count = data_block[k]['block_count']
                block_length = data_block[k]['block_length']
                block_values = data_block[k]['block_values']
                for i in range(block_count):
                    features_ = features.copy()
#                    i=1
                    M[k][i] = {}  #第i块数据的模型
                    data = data_block[k][i]  #第i块数据
                    for j in labels:  #多分类属性的模型训练
                        lable = [j]
#                        print(features,features_,lable)
                        X, Y = divide_XY(data, features_, lable)
                        P_y, P_xy = self.bayes_model(X, Y, continuous=continuous)
                        M[k][i][j] = self.save_model(P_y, P_xy)
                        features_.append(j)
                    # 计算模型可靠性
                    print('----------------------------------')
                    print('训练第{}个划分，第{}个块'.format(k,i))
                    loss= self.classify_tuples(data, M[k][i], labels, SCAREd=0)
                    reliability = block_length[i] / sum(block_length) * (1 - loss)
                    M[k][i]['reliability'] = reliability
                M[k]['block_values'] = block_values
        self.M = M
     
        return M
    
    def classify_block(self, data, M):
        """多划分方法的分类和结果集成（图方法）"""

    def block(self, data, block_features=None, continuous=None, data_path=None):
        """水平划分
        ：feature: list类型；需要划分的列
        ：blok_num: list
        """
        if block_features is None:
            block_features = self.features
        self.parameter(data, continuous=continuous)
        data_block = {}
        for i in block_features:
            data_block[i] = self.block2(data,i,continuous,data_path=data_path)
            print('划分第{}列'.format(i))
            
        return data_block
        
    def block2(self, data, feature, continuous, data_path=None):
        """对具体某一列进行水平划分"""
        # 不对连续数据划分，返回空列表
        if feature in continuous:
            return []
        # 划分参数初始化
        data_block = {}  #存储多个块的数据
        block_count = self.X_count[feature]  #非重复值个数
        block_values = self.X_unique[feature]  #非重复值
        block_length = []  #每个数据块行数
        # 进行划分
        for i in range(block_count):
            data_block[i] = []  #预留每个分块的位置，方便之后放入。
        [data_block[block_values.index(x[feature])].append(x) for x in data]
        # 每个数据块大小计算，存储
        for j in range(block_count):
            block_length.append(len(data_block[j]))
            data_block[j] = np.array(data_block[j])
            if data_path is not None:
                data_path_ = data_path + '\\' + str(feature) + '_' + str(j) + ".csv"
                np.savetxt(data_path_,data_block[j],fmt = '%s',delimiter = ',')
        # 整合
        data_block['block_count'] = block_count
        data_block['block_values'] = block_values
        data_block['block_length'] = block_length

        return data_block
    
    def save_data_block(self, data_block, data_path):
        if data_path is not None:
            f = open(data_path, "wb")
            pi.dump(data_block, f)
            f.close()
        else:
            print("data_path不存在")
            exit()
            
    def load_data_block(self, data_path):
        if data_path is not None:
            f = open(data_path, "rb")
            data_block = pi.load(f)
            f.close()
        else:
            print("data_path不存在")
            exit()

        return data_block
    
    def save_block_model(self, M, model_path):
        f = open(model_path, "wb")
        pi.dump(M, f)
        f.close()
        
def evaluate(classical, test_data, labels):
#        print("evaluate_Begin")
    count = 0
    sum_ = 0
    for i in range(len(test_data)):
        for j in range(len(labels)):
            sum_ +=1 
            if classical[i][j] == test_data[i][labels[j]]:
                count +=1
#            else:
#                print(i, classical[i][0], test_data[i][labels])
#            print(i,count/sum_)
    accuracy = count * 1. / sum_
#    print('accuracy:{}/{}   {}  {}'.format(count,sum_,accuracy,sum_-count))
    return accuracy, sum_/len(labels)

def evaluate2(classical, test_data, label):
#        print("evaluate_Begin")
    count = 0
    sum_ = 0
    for i in range(len(test_data)):
        for j in range(len(labels)):
            sum_ +=1 
            if classical[i][0][j] == test_data[i][labels[j]]:
                count +=1
#            else:
#                print(i, classical[i][0], test_data[i][labels])
#            print(i,count/sum_)
    accuracy = count * 1. / sum_
#        print('evaluate_End')
    return accuracy

def evaluate3(classical, test_data_error,test_data, labels, model=0):
    count = 0
    sum_error = 0
    sum_update = 0
    people = []
    sum_ = 0
    for i in range(len(test_data)):
        for j in range(len(labels)):
            sum_ += 1
            if test_data[i][labels[j]] != test_data_error[i][labels[j]]:
                sum_error += 1
            if classical[i][j] != test_data_error[i][labels[j]]:
                sum_update += 1
                if classical[i][j] == test_data[i][labels[j]]:
#                    print(classical[i][0][j],test_data[i][labels[j]],test_data_error[i][labels[j]])
                    count += 1
        if model == 1:
            people.append(count/sum_update)
#            else:
#                if classical[i][0][j].lower() == test_data_error[i][labels[j]]:
#                    print(classical[i][0][j],test_data_error[i][labels[j]])
#    precision = count / sum_update
#    recall = count / sum_error
#    print('precision:{}/{}  {}  {}\nrecall:{}/{}  {}  {}'.format(count,sum_update,precision,sum_update-count,count,sum_error,recall,sum_error-count))
    if model == 1:
        return count, sum_update, sum_error, people
    else:
        return count, sum_update, sum_error
    
def data_quality_detection(data_clean,data,labels):
    count = 0
    for i in range(len(data)):
        for j in labels:
            if data[i][j] == data_clean[i][j]:
                count += 1
    data_qulity = count/len(data)/len(labels)
    return data_qulity

def error_density(classical,test_data,labels):
    classical = copy.deepcopy(classical)
#    for i in range(len(test_data)):
#        classical[i] = classical[i][:4]
#        classical[i].append(test_data[i,labels])
##    temp = sorted(classical,key=itemgetter(3))
#    temp = sorted(classical,key=itemgetter(3),reverse=True)
    count1 = []
    count2 = []
    b = 0
    a = 0
    sum_ = 0
    for i in range(len(test_data)):
#        a = 0
        for j in range(len(labels)):
            if classical[i][j] != test_data[i][labels[j]]:
                sum_ += 1
    for i in range(len(test_data)):
#        a = 0
        for j in range(len(labels)):
            if classical[i][j] != test_data[i][labels[j]]:
                a += 1
            b += 1        
        count1.append(a/b)
        if sum_ == 0:
            count2.append(0)
        else:
            count2.append(a/sum_)
#    for i in range(100):
#        count2.append(0)
#    for i in range(len(test_data)-100):
#        count2.append(sum(count1[i:i+100])/100/len(labels))
    
#    Line2(count2,np.array(temp)[:,3],title='错误密度',model=6)
#    Line2(count1,count2,title='错误分布',model=11)
    
def Line1(A,B,C,D,E,F,title,model=0):
#    x_max = 2*max(len(A),len(B))
    x_max = 2*len(E)
    for i in range(1,2):
        x = []
        x_max = int(x_max/2)
        print(x_max)
        for i in range(len(A)):
            x.append(i)
    #        if A[i] == 0.89 and x_max == len(A):
    #            x_max = i
        x = np.array(x)
    
        #label在图示(legend)中显示。若为数学公式，则最好在字符串前后添加"$"符号
        #color：b:blue、g:green、r:red、c:cyan、m:magenta、y:yellow、k:black、w:white、、、
        #线型：-  --   -.  :    , 
        #marker：.  ,   o   v    <    *    +    1
        plt.figure(figsize=(10,5))
        plt.grid(linestyle = "--")      #设置背景网格线为虚线
        ax = plt.gca()
        ax.spines['top'].set_visible(False)  #去掉上边框
        ax.spines['right'].set_visible(False) #去掉右边框
        if model == 0:    
        #    plt.plot(x,A,"k--",label="随机森林",linewidth=1.5)
            plt.plot(np.arange(0,len(A)),A,color='black',label="BvSB",linewidth=1.5)
            plt.plot(np.arange(0,len(B)),B,color="red",label="BvSB_倒序",linewidth=1.5)
    #        plt.plot(x,C,color='blue',label="P*BvSB_ACC",linewidth=1.5)
            plt.plot(np.arange(0,len(D)),D,"k--",label="BvSB_确信度",linewidth=1.5)
            plt.plot(np.arange(0,len(E)),E,"r--",label="BvSB_倒序_确信度",linewidth=1.5)
    #        plt.plot(np.arange(0,len(F)),F,"b--",label="确信度—update",linewidth=1.5)
        elif model == 1:
            plt.plot(np.arange(0,len(A)),A,color='black',label="P",linewidth=1.5)
            plt.plot(np.arange(0,len(B)),B,color="red",label="BvSB",linewidth=1.5)
    #        plt.plot(x,C,color='blue',label="P*BvSB_ACC",linewidth=1.5)
    #        plt.plot(x,D,"k--",label="P",linewidth=1.5)
            plt.plot(np.arange(0,len(E)),E,"r--",label="确信度",linewidth=1.5)
            plt.plot(np.arange(0,len(F)),F,"b--",label="确信度—update",linewidth=1.5)
        group_labels = []
        for i in range(len(A)):
            group_labels.append(str(i)) #x轴刻度的标识
        plt.xticks(np.arange(0,x_max,2000),fontsize=12,fontweight='bold') #默认字体大小为10
        plt.yticks(fontsize=12,fontweight='bold')
        plt.title(str(x_max/len(A)),fontsize=12,fontweight='bold')    #默认字体大小为12
        plt.xlabel("SUM",fontsize=13,fontweight='bold')
        plt.ylabel(title,fontsize=13,fontweight='bold')
        plt.xlim(0,x_max)         #设置x轴的范围
#        plt.ylim(min(A[x_max-1],B[x_max-1],C[x_max-1]),1)
#        plt.ylim(min(A[x_max-1],B[x_max-1],C[x_max-1],D[x_max-1],E[x_max-1],F[x_max-1]),1)
    #    plt.xlim()         #设置x轴的范围
        #plt.ylim(0.5,1)
         
        #plt.legend()          #显示各曲线的图例
        plt.legend(loc=0, numpoints=1)
        leg = plt.gca().get_legend()
        ltext = leg.get_texts()
        plt.setp(ltext, fontsize=12,fontweight='bold') #设置图例字体的大小和粗细
         
    #    plt.savefig('E:\\code\\TYT\\result\\act+wei.02\\Line1.svg')  #建议保存为svg格式，再用inkscape转为矢量图emf后插入word中
        plt.show()
        
def Line2(A,B=None,C=None,D=None,E=None,title='图',model=1):

    x = []
    for i in range(len(A)):
        x.append(i)
#        if A[i] == 0.89 and x_max == len(A):
#            x_max = i
    x = np.array(x)

    #label在图示(legend)中显示。若为数学公式，则最好在字符串前后添加"$"符号
    #color：b:blue、g:green、r:red、c:cyan、m:magenta、y:yellow、k:black、w:white、、、
    #线型：-  --   -.  :    , 
    #marker：.  ,   o   v    <    *    +    1
    plt.figure(figsize=(10,5))
    plt.grid(linestyle = "--")      #设置背景网格线为虚线
    ax = plt.gca()
    ax.spines['top'].set_visible(False)  #去掉上边框
    ax.spines['right'].set_visible(False) #去掉右边框
     
#    plt.plot(x,A,"k--",label="随机森林",linewidth=1.5)
    if model == 1:
        plt.plot(np.arange(0,len(A)),A,'r*--',label="BvSB",linewidth=1.5)
        plt.plot(np.arange(0,len(B)),B,'bo--',label="P",linewidth=1.5)
        plt.xlabel("迭代次数",fontsize=13,fontweight='bold')
        plt.ylabel('精度',fontsize=13,fontweight='bold')
    elif model == 2:
        plt.plot(np.arange(0,len(A)),A,'r*--',label="BvSB",linewidth=1.5)
        plt.plot(np.arange(0,len(B)),B,'bo--',label="P",linewidth=1.5)
        plt.xlabel("迭代次数",fontsize=13,fontweight='bold')
        plt.ylabel('回归率',fontsize=13,fontweight='bold')
    elif model == 3:
        plt.plot(np.arange(0,len(A)),A,'r*--',label="BvSB",linewidth=1.5)
        plt.plot(np.arange(0,len(B)),B,'bo--',label="P",linewidth=1.5)
        plt.plot(np.arange(0,len(C)),C,'g-',label="原始数据",linewidth=1.5)
        plt.xlabel("迭代次数",fontsize=13,fontweight='bold')
        plt.ylabel('数据质量',fontsize=13,fontweight='bold')
    elif model == 4:
        plt.plot(np.arange(0,len(A)),A,'r*--',label="BvSB+ACT",linewidth=1.5)
        plt.plot(np.arange(0,len(B)),B,'bo--',label="BvSB+ML",linewidth=1.5)
        plt.xlabel("迭代次数",fontsize=13,fontweight='bold')
        plt.ylabel('精度',fontsize=13,fontweight='bold')
    elif model == 5:
        plt.plot(np.arange(0,len(A)),A,'r*--',label="BvSB+ACT",linewidth=1.5)
        plt.plot(np.arange(0,len(B)),B,'bo--',label="BvSB+ML",linewidth=1.5)
        plt.xlabel("迭代次数",fontsize=13,fontweight='bold')
        plt.ylabel('回归率',fontsize=13,fontweight='bold')
    elif model == 6:
        plt.plot(np.arange(0,len(A)),A,'r*--',label="BvSB+ACT",linewidth=1.5)
        plt.plot(np.arange(0,len(B)),B,'bo--',label="BvSB+ML",linewidth=1.5)
        plt.plot(np.arange(0,len(C)),C,'g-',label="原始数据",linewidth=1.5)
        plt.xlabel("迭代次数",fontsize=13,fontweight='bold')
        plt.ylabel('数据质量',fontsize=13,fontweight='bold')
    elif model == 7:
        plt.plot(np.arange(0,len(A)),A,'r*--',label="BvSB+ACT",linewidth=1.5)
        plt.plot(np.arange(0,len(B)),B,'bo--',label="BvSB+ML",linewidth=1.5)
        plt.plot(np.arange(0,len(C)),C,'cv--',label="BvSB+ACT+RETRAIN",linewidth=1.5)
        plt.xlabel("迭代次数",fontsize=13,fontweight='bold')
        plt.ylabel('精度',fontsize=13,fontweight='bold')
    elif model == 8:
        plt.plot(np.arange(0,len(A)),A,'r*--',label="BvSB+ACT",linewidth=1.5)
        plt.plot(np.arange(0,len(B)),B,'bo--',label="BvSB+ML",linewidth=1.5)
        plt.plot(np.arange(0,len(C)),C,'cv--',label="BvSB+ACT+RETRAIN",linewidth=1.5)
        plt.xlabel("迭代次数",fontsize=13,fontweight='bold')
        plt.ylabel('回归率',fontsize=13,fontweight='bold')
    elif model == 9:
        plt.plot(np.arange(0,len(A)),A,'r*--',label="BvSB+ACT",linewidth=1.5)
        plt.plot(np.arange(0,len(B)),B,'bo--',label="BvSB+ML",linewidth=1.5)
        plt.plot(np.arange(0,len(C)),C,'g-',label="原始数据",linewidth=1.5)
        plt.plot(np.arange(0,len(D)),D,'cv--',label="BvSB+ACT+RETRAIN",linewidth=1.5)
        plt.xlabel("迭代次数",fontsize=13,fontweight='bold')
        plt.ylabel('数据质量',fontsize=13,fontweight='bold')
    elif model == 10:
        plt.plot(np.arange(0,len(A)),A,'r*--',linewidth=1.5)
        plt.xlabel("迭代次数",fontsize=13,fontweight='bold')
        plt.ylabel('人参与度',fontsize=13,fontweight='bold')
    elif model == 11:
        plt.plot(np.arange(0,len(A)),A,'r-',linewidth=1.5)
        plt.plot(np.arange(0,len(B)),B,'b-',linewidth=1.5)
        plt.xlabel("数据量",fontsize=13,fontweight='bold')
        plt.ylabel('错误率',fontsize=13,fontweight='bold')
    elif model == 12:
        plt.plot(np.arange(0,len(A)),A,'r*--',label="ACT-M",linewidth=1.5)
        plt.xlabel("迭代次数",fontsize=13,fontweight='bold')
        plt.ylabel('数据质量',fontsize=13,fontweight='bold')
    elif model == 13:
        plt.plot(np.arange(0,len(A)),A,'r*--',label="人判断部分",linewidth=1.5)
        plt.plot(np.arange(0,len(B)),B,'b*--',label="机器判断部分",linewidth=1.5)
        plt.xlabel("迭代次数",fontsize=13,fontweight='bold')
        plt.ylabel('机器错误数据量',fontsize=13,fontweight='bold')
    elif model == 14:
        plt.plot(np.arange(0,len(A)),A,'r*--',label="人检查准确率",linewidth=1.5)
        plt.xlabel("查看条数",fontsize=13,fontweight='bold')
        plt.ylabel('正确数据比例',fontsize=13,fontweight='bold')
    elif model == 15:
        plt.plot(np.arange(0,len(A)),A,'r-',label="人",linewidth=1.5)
        plt.xlabel("迭代次数",fontsize=13,fontweight='bold')
        plt.ylabel('查看数据条数',fontsize=13,fontweight='bold')
    elif model == 16:
        plt.plot(np.arange(0,len(A)),A,'r-',label="修复后",linewidth=1.5)
        plt.plot(np.arange(0,len(B)),B,'b-',label="原数据",linewidth=1.5)
        plt.xlabel("迭代次数",fontsize=13,fontweight='bold')
        plt.ylabel('数据质量',fontsize=13,fontweight='bold')
#        plt.plot(x,C,color='blue',label="P*BvSB_ACC",linewidth=1.5)
#        plt.plot(x,D,"k--",label="P",linewidth=1.5)
#        plt.plot(x,E,"r--",label="BvSB",linewidth=1.5)
#        plt.plot(x,F,"b--",label="P*BvSB",linewidth=1.5)
    group_labels = []
    for i in range(len(A)):
        group_labels.append(str(i)) #x轴刻度的标识
    plt.xticks(np.arange(0,len(x)),fontsize=12,fontweight='bold') #默认字体大小为10
    plt.yticks(fontsize=12,fontweight='bold')
    plt.title(title,fontsize=12,fontweight='bold')    #默认字体大小为12
    if model == 11:
        plt.xticks(np.arange(0,len(x),100),fontsize=12,fontweight='bold') #默认字体大小为10
#    plt.xlim(0,x_max)         #设置x轴的范围
#        plt.ylim(min(A[x_max-1],B[x_max-1],C[x_max-1]),1)
#        plt.ylim(min(A[x_max-1],B[x_max-1],C[x_max-1],D[x_max-1],E[x_max-1],F[x_max-1]),1)
#    plt.xlim()         #设置x轴的范围
    #plt.ylim(0.5,1)
     
    #plt.legend()          #显示各曲线的图例
    plt.legend(loc=0, numpoints=1)
    leg = plt.gca().get_legend()
    ltext = leg.get_texts()
    plt.setp(ltext, fontsize=12,fontweight='bold') #设置图例字体的大小和粗细

    if model == 15: 
        plt.savefig('D:\\论文\\NDBC\\Line1.svg')  #建议保存为svg格式，再用inkscape转为矢量图emf后插入word中
    if model == 16: 
        plt.savefig('D:\\论文\\NDBC\\Line2.svg')  #建议保存为svg格式，再用inkscape转为矢量图emf后插入word中
    plt.show()

def get_ite_data(classical1,test_data_error,test_data,labels):
    '''划分为更新数据和不更新数据
    ：model: 1:BvSB
            2.P
    '''
    classical = copy.deepcopy(classical1)
    for i in range(len(classical)):
        classical[i] = classical[i][:4]
        classical[i].append(test_data_error[i].copy())
        classical[i].append(test_data[i].copy())
        classical[i].append(test_data_error[i,labels].copy())
        classical[i].append(test_data[i,labels].copy())
    temp_B = sorted(classical,key=itemgetter(3))
    temp11 = []
    temp12 = []
    temp13 = []
    temp14 = []
    temp15 = []
    temp16 = []
    temp17 = []
    temp1 = []
    temp2 = []
    k = 0
    l = 0
    for i in range(len(temp_B)):
        if not (temp_B[i][0] == temp_B[i][6]).all():
#            if temp_B[i][3] == 0:
#                print(temp_B[i])
            temp11.append(temp_B[i][0].copy())  #更新的修改数据（类别属性）
            temp12.append(temp_B[i][4].copy())  #更新的脏数据
            temp13.append(temp_B[i][5].copy())  #更新的干净数据
#            if not (temp_B[i][0] == temp_B[i][7]).all() and k < (len(test_data)*0.2):
#                temp17.append(temp_B[i][5].copy())
#                k += 1
            temp1.append(temp_B[i][4].copy())  #更新的修改数据（特征属性+类别属性）
            for j in range(len(labels)):
                if temp1[l][labels[j]] != temp_B[i][0][j]:
                    temp1[l][labels[j]] = temp_B[i][0][j]
            l += 1
        else:
            temp14.append(temp_B[i][0].copy())  #不更新的的修改数据（类别属性）
            temp15.append(temp_B[i][4].copy())  #不更新的脏数据
            temp16.append(temp_B[i][5].copy())  #不更新的干净数据
            temp2.append(temp_B[i][4].copy())  #更新的修改数据（特征属性+类别属性）
            for j in range(len(labels)):
                if temp2[k][labels[j]] != temp_B[i][0][j]:
                    temp2[k][labels[j]] = temp_B[i][0][j]
            k += 1
    error_density(temp11,temp13,labels)
    return np.array(temp1),np.array(temp11),np.array(temp12),np.array(temp13),\
        np.array(temp2),np.array(temp14),np.array(temp15),np.array(temp16)\
#        ,np.array(temp17)

def get_ite_data2(classical1,test_data_error,test_data,labels,model):
    '''划分为更新数据和不更新数据
    ：model: 1:BvSB
            2.P
    '''
    classical = copy.deepcopy(classical1)
    for i in range(len(classical)):
        classical[i] = classical[i][:4]
        classical[i].append(test_data_error[i].copy())
        classical[i].append(test_data[i].copy())
        classical[i].append(test_data_error[i,labels].copy())
        classical[i].append(test_data[i,labels].copy())
    temp_B = sorted(classical,key=itemgetter(3))
    temp_P = sorted(classical,key=itemgetter(1))
    temp11 = []
    temp12 = []
    temp13 = []
    temp14 = []
    temp15 = []
    temp16 = []
    temp17 = []
    temp21 = []
    temp22 = []
    temp23 = []
    temp24 = []
    temp25 = []
    temp26 = []
    temp = []
    k = 0
    l = 0
    for i in range(len(temp_B)):
        if not (temp_B[i][0] == temp_B[i][6]).all():
            temp11.append(temp_B[i][0].copy())  #更新的修改数据（类别属性）
            temp12.append(temp_B[i][4].copy())  #更新的脏数据
            temp13.append(temp_B[i][5].copy())  #更新的干净数据
            if not (temp_B[i][0] == temp_B[i][7]).all() and k < (len(test_data)*0.2):
                temp17.append(temp_B[i][5].copy())
                k += 1
            temp.append(temp_B[i][4].copy())  #更新的修改数据（特征属性+类别属性）
            for j in range(len(labels)):
                if temp[l][labels[j]] != temp_B[i][0][j]:
                    temp[l][labels[j]] = temp_B[i][0][j]
            l += 1
        else:
            temp14.append(temp_B[i][0].copy())  #不更新的的修改数据（类别属性）
            temp15.append(temp_B[i][4].copy())  #不更新的脏数据
            temp16.append(temp_B[i][5].copy())  #不更新的干净数据
    for i in range(len(temp_P)):
        if not (temp_P[i][0] == temp_P[i][6]).all():
            temp21.append(temp_P[i][0].copy())  #更新的修改数据（类别属性）
            temp22.append(temp_P[i][4].copy())  #更新的脏数据
            temp23.append(temp_P[i][5].copy())  #更新的干净数据
#                temp5.append(temp_B[i][4].copy())  #执行的修改数据（特征属性+类别属性）
#                for j in range(len(labels)):
#                    if temp5[l][labels[j]] != temp_B[i][0][j]:
#                        temp5[l][labels[j]] = temp_B[i][0][j]
#                l += 1
        else:
            temp24.append(temp_P[i][0].copy())  #不更新的修改数据（类别属性）
            temp25.append(temp_P[i][4].copy())  #不更新的脏数据
            temp26.append(temp_P[i][5].copy())  #不更新的干净数据
    if model == 1:
        error_density(temp11,temp13,labels)
        return np.array(temp11),np.array(temp12),np.array(temp13),\
            np.array(temp14),np.array(temp15),np.array(temp16),np.array(temp17)
    else:
#        error_density(temp21,temp23,labels)
        return np.array(temp21),np.array(temp22),np.array(temp23),\
            np.array(temp24),np.array(temp25),np.array(temp26)
            
def active(data_new,data_error,data_clean,labels,satisfaction=0.2,N=None):
    if not N:
        N = len(labels)*2
    update_num = 0
    right1 = [0 for i in range(N)]
    right2 = []
    for i in range(len(data_new)):
        for j in labels:
            if data_new[i][j] != data_error[i][j]:
                if data_new[i][j] != data_clean[i][j]:
#                print(right1)
                    right1.pop(0)
                    right1.append(1)
                else:
                    right1.pop(0)
                    right1.append(0)
                update_num += 1 
            if update_num >= N:
                a = sum(right1)/N
                right2.append(a)
                if a <= satisfaction or i==len(data_new)-1:
                    title = '正确更新数/每'+str(N)+'个值'
                    Line2(right2,title=title,model=15)
                    return data_new[:i+1],data_clean[:i+1],data_error[:i+1],\
                        data_new[i+1:],data_clean[i+1:],data_error[i+1:],update_num
    
def init():
    # 初始数据
    data_path = "E:\\code\\bayes-python\\act"
    train_path = data_path + "\\train_data\\train_data0.csv"
    train_error_path = data_path + "\\train_data\\train_data_error0.csv"
    train_data = load_data(train_path)
    train_data_error = load_data(train_error_path)
    # 初始模型
    model_path = "E:\\code\\bayes-python\\act\\model\\M0.pkl"
    SC.model_train(features,labels,data=train_data,model_path=model_path,continuous=continuous)
    # 数据质量预估
    data_quality_init = data_quality_detection(train_data,train_data_error,labels)    
    return data_quality_init

def ite():
    data_quality_int = init()
    # 导入数据
    data_path = "E:\\code\\bayes-python\\act"
    test_path = data_path + "\\test_data\\test_data.csv"
    test_error_path = data_path + "\\test_data\\test_data_error.csv"
    train_path = data_path + "\\train_data\\train_data0.csv"
    train_error_path = data_path + "\\train_data\\train_data_error0.csv"
    test_data = load_data(test_path)
    test_data_error = load_data(test_error_path)
    train_data = load_data(train_path)
    train_data_error = load_data(train_error_path)
    # 初始变量
    flag = 1  #第一次迭代
    start = 0  #测试集首标
    count = 0  #人满意数据组数
    people_effort = [len(train_data)/(len(test_data)+len(train_data))]  #人参与度
    data_quality1_ = data_quality_detection(test_data,test_data_error,labels)
    data_quality1 = []  #原始数据质量
    data_quality2 = []  #每次清洗后数据质量
    # 迭代清洗
    while(flag!=0):
        print(flag,count,"===============")
        # 清洗数据
        end = start + 100
        data = test_data[start:end]
        data_error = test_data_error[start:end]
        # 导入模型
        model_path = "E:\\code\\bayes-python\\act\\model\\M" + str(flag-1) + ".pkl"
        M = BC.load_model(model_path)
        # 生成修复建议
        classical_P,classical_BvSB = SC.classify_tuples(data_error,M,labels,data_quality=data_quality_int)
        # 筛选修复的数据
        data_Bu,data_Bu_l,data_Bu_e,data_Bu_c,data_Bn,data_Bn_l,data_Bn_e,data_Bn_c\
            =get_ite_data(classical_BvSB,data_error,data,labels)
        # 划分人查看+未查看的机器建议修复数据+人查看的数据数量（行数）
        data_act,data_act_clean,data_act_error,data_not_act,data_not_act_clean,data_not_act_error,check_num\
            = active(data_Bu,data_Bu_e,data_Bu_c,labels)
        # 重新组织训练集
        train_data = np.row_stack([train_data,data_act_clean])  #插入人看过且机器分类错误的数据
        train_data_error = np.row_stack([train_data_error,data_act_error])
        # 人未看的数据汇总
        if flag == 1:
            test_data_fin = np.row_stack([data_not_act,data_Bn_e])
        else:
            test_data_fin = np.row_stack([test_data_fin,data_not_act])
            test_data_fin = np.row_stack([test_data_fin,data_Bn_e])
        # 新训练集存储
        train_path_fin = data_path + "\\train_data\\train_data" + str(flag+1) + ".csv"
#        if not os.path.exists(train_path3):
#            sys.exit(0)
        train_data = pd.DataFrame(train_data)
        train_data.to_csv(train_path_fin,header=None,index=None)
        # 最后待清洗数据汇总存储
        # 重新训练模型+存储
        train_data = np.array(train_data)
        model_path_ite = "E:\\code\\bayes-python\\act\\model\\M" + str(flag) + ".pkl"
        M2 = SC.model_train(features,labels,data=train_data,model_path=model_path_ite,continuous=continuous)
        # 相关信息记录和更新
        start = end  #下一轮数据首标
        if check_num <= len(labels)*5:  #人看的数据不到 *** 条，则记录。反映人对数据质量总体满意程度
            count += 1
        else:
            count = 0
        people_effort.append(people_effort[-1]+check_num/(len(test_data)+len(train_data))/len(labels))  #用于评估人的参与度  
        if flag == 1:  #人未看的数据对应的干净数据汇总；用于最后一次检查筛选出更新数据：实验用
            test_data_clean_fin = np.row_stack([data_not_act_clean,data_Bn_c])
        else:
            test_data_clean_fin = np.row_stack([test_data_clean_fin,data_not_act_clean])
            test_data_clean_fin = np.row_stack([test_data_clean_fin,data_Bn_c])
        data_evaluate_done = np.row_stack([train_data,test_data_fin])  # 用于评估数据质量的变化；修复后
        data_evaluate_done = np.row_stack([data_evaluate_done,test_data_error[end:]])
        data_evaluate_clean = np.row_stack([train_data,test_data_clean_fin])  # 用于评估数据质量的变化：修复前
        data_evaluate_clean = np.row_stack([data_evaluate_clean,test_data[end:]])
        flag += 1
        # 评估
        data_quality1.append(data_quality1_)  #原数据质量
        data_quality_temp = data_quality_detection(data_evaluate_clean,data_evaluate_done,labels)  #现在数据质量
        data_quality2.append(data_quality_temp)
#        count,sum_update,sum_error,people = evaluate3(data_Ba_l,data_Ba_e,data_Ba_c, labels,model=1)  
        Line2(people_effort,title='人的参与度/ 轮',model=15)
        Line2(data_quality2,data_quality1,title='数据质量/ 轮',model=16)
        
        # 是否执行最后一次检查
        if count >= 5 or start >= len(test_data):  #1.连续5组数据，人满意度达标，终止迭代，进入最终检查；2.没有数据迭代了
#            flag=0
            test_data_fin = np.row_stack([test_data_fin,test_data_error[end:]])
            test_data_clean_fin = np.row_stack([test_data_clean_fin,test_data[end:]])
            begin_time = time.clock()
            classical_P2,classical_BvSB2 = SC.classify_tuples(test_data_fin,M2,labels,data_quality=data_quality_int)
            end_time = time.clock()
            print(end_time - begin_time)
            # 筛选修复的数据
            data_Bu2,data_Bu_l2,data_Bu_e2,data_Bu_c2,data_Bn2,data_Bn_l2,data_Bn_e2,data_Bn_c2\
                =get_ite_data(classical_BvSB2,test_data_fin,test_data_clean_fin,labels)
            # 最后检查，满意度调小，清洗要求增高
            data_act2,data_act_clean2,data_act_error2,\
            data_not_act2,data_not_act_clean2,data_not_act_error2,check_num2\
            = active(data_Bu2,data_Bu_e2,data_Bu_c2,labels,satisfaction=0.1,N=10)
            # 所有人检查过的数据和机器决定的数据汇总
            data_fin = np.row_stack([train_data,data_act_clean2])
            data_fin = np.row_stack([data_fin,data_not_act2])
            data_fin = np.row_stack([data_fin,data_Bn_e2])
            # 评估
            # 错误数据
            data_clean_fin = np.row_stack([train_data,data_act_clean2])
            data_clean_fin = np.row_stack([data_clean_fin,data_not_act_clean2])
            data_clean_fin = np.row_stack([data_clean_fin,data_Bn_c2])
            data_quality_temp = data_quality_detection(data_clean_fin,data_fin,labels)  #现在数据质量
            data_quality1.append(data_quality1_)  #原数据质量
            data_quality2.append(data_quality_temp)
            people_effort.append(people_effort[-1]+check_num2/(len(test_data)+len(train_data))/len(labels))  #用于评估人的参与度  
            Line2(people_effort,title='人的参与度/ 轮',model=15)
            Line2(data_quality2,data_quality1,title='数据质量/轮',model=16)
            print(len(train_data),len(data_act2),len(data_not_act2))
            print(people_effort[-1],data_quality2[-1])
            # 结束
            flag = 0

# =============================================================================
# def SCAREd_tuples(ite):
#     print(ite,'===============================================================')
#     
#     data_path = "E:\\code\\bayes-python\\act\\"
#     test_path = data_path +"test_data\\test_data" + str(ite) + ".csv"
#     if not os.path.exists(test_path):
#         sys.exit(0)
#     train_path = data_path + "train_data\\train_data" + str(ite) + ".csv"
#     train_data = load_data(train_path)
#     X, Y = divide_XY(train_data, features, labels)
#     # 训练+存储模型
#     model_path = "E:\\code\\bayes-python\\act\\model\\M" + str(ite) + ".pkl"
#     if ite == 0:
#         M = SC.model_train(features, labels, data=train_data, model_path=model_path, continuous=continuous)
#     # 导入模型
#     else:
#         M = BC.load_model(model_path)
#     '''================================================================================='''
#     # 导入测试集
#     test_error_path = data_path + "test_data\\test_data_error" + str(ite) + ".csv"
#     test_path = data_path +"test_data\\test_data" + str(ite) + ".csv"
#     test_data_error = load_data(test_error_path)
#     test_data = load_data(test_path)
#     # 分类
#     classical_P,classical_BvSB = SC.classify_tuples(test_data_error, M, labels)
#     # 数据划分+评估
#     data_Bu_l,data_Bu_e,data_Bu_c,data_Bn_l,data_Bn_e,data_Bn_c,data_Bw_c\
#         =get_ite_data2(classical_BvSB,test_data_error,test_data,labels,model=1)
#     data_Pu_l,data_Pu_e,data_Pu_c,data_Pn_l,data_Pn_e,data_Pn_c\
#         =get_ite_data2(classical_P,test_data_error,test_data,labels,model=2)
#         
#     i = int(len(data_Bu_l) * 0.2)  #人参与BvSB
#     data_Ba_l = data_Bu_l[:i]
#     data_Ba_e = data_Bu_e[:i]
#     data_Ba_c = data_Bu_c[:i]
#     data_B_l = data_Bu_l[i:]
#     data_B_e = data_Bu_e[i:]
#     data_B_c = data_Bu_c[i:]
#     
#     i = int(len(data_Pu_l) * 0.2)  #人参与P
#     data_Pa_l = data_Pu_l[:i]
#     data_Pa_e = data_Pu_e[:i]
#     data_Pa_c = data_Pu_c[:i]
#     data_P_l = data_Pu_l[i:]
#     data_P_e = data_Pu_e[i:]
#     data_P_c = data_Pu_c[i:]
#     
#     count1, sum_update1, sum_error1, people = evaluate3(data_Ba_l,data_Ba_e,data_Ba_c, labels,model=1)
#     count2, sum_update2, sum_error2 = evaluate3(data_B_l,data_B_e,data_B_c, labels)
#     count3, sum_update3, sum_error3 = evaluate3(data_Pa_l,data_Pa_e,data_Pa_c, labels)
#     count4, sum_update4, sum_error4 = evaluate3(data_P_l,data_P_e,data_P_c, labels)
#     count5, sum_update5, sum_error5 = evaluate3(data_Bn_l,data_Bn_e,data_Bn_c,labels)
#     count6, sum_update6, sum_error6 = evaluate3(data_Pn_l,data_Pn_e,data_Pn_c,labels)
#     
#     Line2(people,title="people",model=14)
#     
#     
#     count_B = sum_error1 + count2
#     sum_update_B = sum_error1 + sum_update2
#     sum_error_B = sum_error1 + sum_error2 + sum_error5
#     
#     count_P = sum_error3 + count4
#     sum_update_P = sum_error3 + sum_update4
#     sum_error_P = sum_error3 + sum_error4 + sum_error6
#     
#     count_B_M = count1 + count2
#     sum_update_B_M = sum_update1 + sum_update2
#     count_P_M = count3 + count4
#     sum_update_P_M = sum_update3 + sum_update4
# #    print('actB: precision:{}\t recall:{}\n actP: precision:{}\t recall:{}\nsum_errorB:{}\nsum_errorP:{}'.format(count_B/sum_update_B,count_B/sum_error_B,count_P/sum_update_P,count_P/sum_error_P,sum_error_B,sum_error_P))
# #    print('count5:{}\ncount6:{}\nupdate5:{}\nupdate6:{}\nsum_error5:{}\nsum_error6:{}\n'.format(count5,count6,sum_update5,sum_update6,sum_error5,sum_error6))
# #    print('not-act: precision:{}\n recall:{}'.format(count/sum_update,count/sum_error))
# # 评价指标计算 精度、回归率、数据质量
#     #人参与度
#     update.append(sum_update1)
#     length.append(len(classical_BvSB)*len(labels))
#     people_effort.append(sum(update)/sum(length))
# #    Line2(people_effort,title='People\'s effort',model=10)
#     # 原始数据质量
#     data_quality.append(1-(sum_error1+sum_error2+sum_error5)/len(classical_BvSB)/len(labels))
#     data_quality_ALL_not.append(sum_error1+sum_error2+sum_error5)
#     data_quality_ALL.append(1-(sum(data_quality_ALL_not)/sum(length)))
#     # 仅机器
#     precision_B_M.append(count_B_M/sum_update_B_M) 
#     precision_P_M.append(count_P_M/sum_update_P_M)
#     recall_B_M.append(count_B_M/sum_error_B)  
#     recall_P_M.append(count_P_M/sum_error_P)
#     data_quality_B_M.append(1-(sum_error1+sum_error2+sum_update1+sum_update2-2*count1-2*count2+sum_error5)/len(classical_BvSB)/len(labels))
#     data_quality_P_M.append(1-(sum_error3+sum_error4+sum_update3+sum_update4-2*count3-2*count4+sum_error6)/len(classical_P)/len(labels))
# #    Line2(precision_B_M,precision_P_M,title="ML+BVSB+P",model=1)
# #    Line2(recall_B_M,recall_P_M,title="ML+BVSB+P",model=2)
# #    Line2(data_quality_B_M,data_quality_P_M,data_quality,title="ML+BVSB+P",model=3)
#     # 人+机器参与
#     precision_B.append(count_B/sum_update_B) 
#     precision_P.append(count_P/sum_update_P)
#     recall_B.append(count_B/sum_error_B)  
#     recall_P.append(count_P/sum_error_P)
#     data_quality_B.append(1-(sum_error2-2*count2+sum_update2+sum_error5)/len(classical_BvSB)/len(labels))
#     data_quality_P.append(1-(sum_error4-2*count4+sum_update4+sum_error6)/len(classical_P)/len(labels))
# 
#     data_quality_B_M_ALL_not.append(sum_error1+sum_error2+sum_update1+sum_update2-2*count1-2*count2+sum_error5)
#     data_quality_B_M_ALL.append(1-(sum(data_quality_B_ALL_not)+data_quality_B_M_ALL_not[-1])/sum(length))
#     data_quality_B_ALL_not.append(sum_error2-2*count2+sum_update2+sum_error5)
#     data_quality_B_ALL.append(1-sum(data_quality_B_ALL_not)/sum(length))
# #    Line2(precision_B,precision_B_M,title="ACT+ML",model=4)
# #    Line2(recall_B,recall_B_M,title="ACT+ML",model=5)
#     Line2(data_quality_B,data_quality_B_M,data_quality,title="ACT+ML",model=6)
# #    Line2(np.array(data_quality_B)-np.array(data_quality_B_M),title="ACT - ML",model=12)
# #    Line2(data_quality_B_ALL,data_quality_B_M_ALL,data_quality_ALL,title="ACT+ML+ALL",model=6)
#     
#     a1.append(sum_update1)
#     a2.append(count1)
#     b1.append(sum_update2)
#     b2.append(count2)
# #    Line2(np.array(a1)-np.array(a2),np.array(b1)-np.array(b2),title="# ACT - ML",model=13)
# #    Line2((np.array(a1)-np.array(a2))/np.array(a1),(np.array(b1)-np.array(b2))/np.array(b1),title="% ACT - ML",model=13)
#     '''===========================测试集============================================================='''
#     # 测试集
#     test_error_path2 = data_path + "test_data\\test_data_error.csv"
#     test_path2 = data_path + "test_data\\test_data.csv"
#     test_data_error2 = load_data(test_error_path2)
#     test_data2 = load_data(test_path2)
#     classical_P2,classical_BvSB2 = SC.classify_tuples(test_data_error2, M, labels)
#     data_Bu_l2,data_Bu_e2,data_Bu_c2,data_Bn_l2,data_Bn_e2,data_Bn_c2,data_Bw_c2\
#         =get_ite_data2(classical_BvSB2,test_data_error2,test_data2,labels,model=1)
#     data_Pu_l2,data_Pu_e2,data_Pu_c2,data_Pn_l2,data_Pn_e2,data_Pn_c2\
#         =get_ite_data2(classical_P2,test_data_error2,test_data2,labels,model=2)
#         
#     i = int(len(data_Bu_l2) * 0.2)  #人参与BvSB
#     data_Ba_l2 = data_Bu_l2[:i]
#     data_Ba_e2 = data_Bu_e2[:i]
#     data_Ba_c2 = data_Bu_c2[:i]
#     data_B_l2 = data_Bu_l2[i:]
#     data_B_e2 = data_Bu_e2[i:]
#     data_B_c2 = data_Bu_c2[i:]
#     
#     i = int(len(data_Pu_l2) * 0.2)  #人参与P
#     data_Pa_l2 = data_Pu_l2[:i]
#     data_Pa_e2 = data_Pu_e2[:i]
#     data_Pa_c2 = data_Pu_c2[:i]
#     data_P_l2 = data_Pu_l2[i:]
#     data_P_e2 = data_Pu_e2[i:]
#     data_P_c2 = data_Pu_c2[i:]
#     
#     count12, sum_update12, sum_error12 = evaluate3(data_Ba_l2,data_Ba_e2,data_Ba_c2, labels)
#     count22, sum_update22, sum_error22 = evaluate3(data_B_l2,data_B_e2,data_B_c2, labels)
#     count32, sum_update32, sum_error32 = evaluate3(data_Pa_l2,data_Pa_e2,data_Pa_c2, labels)
#     count42, sum_update42, sum_error42 = evaluate3(data_P_l2,data_P_e2,data_P_c2, labels)
#     count52, sum_update52, sum_error52 = evaluate3(data_Bn_l2,data_Bn_e2,data_Bn_c2,labels)
#     count62, sum_update62, sum_error62 = evaluate3(data_Pn_l2,data_Pn_e2,data_Pn_c2,labels)
#     
#     count_B2 = sum_error12 + count22
#     sum_update_B2 = sum_error12 + sum_update22
#     sum_error_B2 = sum_error12 + sum_error22 + sum_error52
#     
#     count_P2 = sum_error32 + count42
#     sum_update_P2 = sum_error32 + sum_update42
#     sum_error_P2 = sum_error32 + sum_error42 + sum_error62
#     
#     count_B_M2 = count12 + count22
#     sum_update_B_M2 = sum_update12 + sum_update22
#     count_P_M2 = count32 + count42
#     sum_update_P_M2 = sum_update32 + sum_update42
# #    print('actB: precision:{}\t recall:{}\n actP: precision:{}\t recall:{}\nsum_errorB:{}\nsum_errorP:{}'.format(count_B2/sum_update_B2,count_B2/sum_error_B2,count_P2/sum_update_P2,count_P2/sum_error_P2,sum_error_B2,sum_error_P2))
# #    print('count5:{}\ncount6:{}\nupdate5:{}\nupdate6:{}\nsum_error5:{}\nsum_error6:{}\n'.format(count52,count62,sum_update52,sum_update62,sum_error52,sum_error62))
# #    print('not-act: precision:{}\n recall:{}'.format(count/sum_update,count/sum_error))
# # 评价指标计算 精度、回归率、数据质量
#     #人参与度
#     people_effort2.append(sum_update1/len(classical_BvSB)/len(labels))
# #    Line2(people_effort2,title='People\'s effort + test',model=10)
#     # 原始数据质量
#     data_quality2.append(1-(sum_error12+sum_error22+sum_error52)/len(classical_BvSB2)/len(labels))
#     # 仅机器
#     precision_B_M2.append(count_B_M2/sum_update_B_M2) 
#     precision_P_M2.append(count_P_M2/sum_update_P_M2)
#     recall_B_M2.append(count_B_M2/sum_error_B2)  
#     recall_P_M2.append(count_P_M2/sum_error_P2)
#     data_quality_B_M2.append(1-(sum_error12+sum_error22+sum_update12+sum_update22-2*count12-2*count22+sum_error52)/len(classical_BvSB2)/len(labels))
#     data_quality_P_M2.append(1-(sum_error32+sum_error42+sum_update32+sum_update42-2*count32-2*count42+sum_error62)/len(classical_P2)/len(labels))
# #    Line2(precision_B_M2,precision_P_M2,title="ML+BVSB+P+test",model=1)
# #    Line2(recall_B_M2,recall_P_M2,title="ML+BVSB+P+test",model=2)
# #    Line2(data_quality_B_M2,data_quality_P_M2,data_quality2,title="ML+BVSB+P+test",model=3)
#     # 人+机器参与
#     precision_B2.append(count_B2/sum_update_B2) 
#     precision_P2.append(count_P2/sum_update_P2)
#     recall_B2.append(count_B2/sum_error_B2)  
#     recall_P2.append(count_P2/sum_error_P2)
#     data_quality_B2.append(1-(sum_error22-2*count22+sum_update22+sum_error52)/len(classical_BvSB2)/len(labels))
#     data_quality_P2.append(1-(sum_error42-2*count42+sum_update42+sum_error62)/len(classical_P2)/len(labels))
# #    Line2(precision_B2,precision_B_M2,title="ACT+ML+test",model=4)
# #    Line2(recall_B2,recall_B_M2,title="ACT+ML+test",model=5)
# #    Line2(data_quality_B2,data_quality_B_M2,data_quality2,title="ACT+ML+test",model=6)
#     '''===============================再训练======================================================='''
#     # 训练集扩充 
#     train_path3 = data_path + "train_data\\train_data" + str(ite+1) + ".csv"
# #    train_data3 = np.row_stack([train_data,data_Ba_c])  #插入人看过的数据
#     if not os.path.exists(train_path3):
#         sys.exit(0)
#     train_data3 = np.row_stack([train_data,data_Bw_c])  #插入人看过且机器分类错误的数据
#     train_data3 = pd.DataFrame(train_data3)
#     train_data3.to_csv(train_path3,header=None,index=None)
#     train_data3 = np.array(train_data3)
# 
#     test_data_error3 = np.row_stack([data_B_e,data_Bn_e])
#     test_data3 = np.row_stack([data_B_c,data_Bn_c])
# 
#     # 重新训练模型
#     model_path3 = "E:\\code\\bayes-python\\act\\model\\M" + str(ite+1) + ".pkl"
#     M3 = SC.model_train(features, labels, data=train_data3, model_path=model_path3, continuous=continuous)
#     classical_P3,classical_BvSB3 = SC.classify_tuples(test_data_error3, M3, labels)
#     
#     data_Bu_l3,data_Bu_e3,data_Bu_c3,data_Bn_l3,data_Bn_e3,data_Bn_c3,data_Bw_c3\
#         =get_ite_data2(classical_BvSB3,test_data_error3,test_data3,labels,model=1)
#     data_Pu_l3,data_Pu_e3,data_Pu_c3,data_Pn_l3,data_Pn_e3,data_Pn_c3\
#         =get_ite_data2(classical_P3,test_data_error3,test_data3,labels,model=2)
#         
#     count2, sum_update2, sum_error2 = evaluate3(data_Bu_l3,data_Bu_e3,data_Bu_c3, labels)
#     count4, sum_update4, sum_error4 = evaluate3(data_Pu_l3,data_Pu_e3,data_Pu_c3, labels)
#     count5, sum_update5, sum_error5 = evaluate3(data_Bn_l3,data_Bn_e3,data_Bn_c3,labels)
#     count6, sum_update6, sum_error6 = evaluate3(data_Pn_l3,data_Pn_e3,data_Pn_c3,labels)
#     count_B = sum_error1 + count2
#     sum_update_B = sum_error1 + sum_update2
#     sum_error_B = sum_error1 + sum_error2 + sum_error5
#     
#     count_P = sum_error3 + count4
#     sum_update_P = sum_error3 + sum_update4
#     sum_error_P = sum_error3 + sum_error4 + sum_error6
#     
#     count_B_M = count1 + count2
#     sum_update_B_M = sum_update1 + sum_update2
#     count_P_M = count3 + count4
#     sum_update_P_M = sum_update3 + sum_update4
# #    print('actB: precision:{}\t recall:{}\n actP: precision:{}\t recall:{}\nsum_errorB:{}\nsum_errorP:{}'.format(count_B/sum_update_B,count_B/sum_error_B,count_P/sum_update_P,count_P/sum_error_P,sum_error_B,sum_error_P))
# #    print('count5:{}\ncount6:{}\nupdate5:{}\nupdate6:{}\nsum_error5:{}\nsum_error6:{}\n'.format(count5,count6,sum_update5,sum_update6,sum_error5,sum_error6))
# #    print('not-act: precision:{}\n recall:{}'.format(count/sum_update,count/sum_error))
# # 评价指标计算 精度、回归率、数据质量
#     # 人+机器参与
#     precision_B_R.append(count_B/sum_update_B) 
#     precision_P_R.append(count_P/sum_update_P)
#     recall_B_R.append(count_B/sum_error_B)
#     recall_P_R.append(count_P/sum_error_P)
#     data_quality_B_R.append(1-(sum_error2-2*count2+sum_update2+sum_error5)/len(classical_BvSB)/len(labels))
#     data_quality_P_R.append(1-(sum_error4-2*count4+sum_update4+sum_error6)/len(classical_P)/len(labels))
# #    Line2(precision_B,precision_B_M,precision_B_R,title="ACT+ML+retrain",model=7)
# #    Line2(recall_B,recall_B_M,recall_B_R,title="ACT+ML+retrain",model=8)
# #    Line2(data_quality_B,data_quality_B_M,data_quality,data_quality_B_R,title="ACT+ML+retrain",model=9)
#     '''=================测试集再训练============================'''
# #    train_data4 = np.row_stack([train_data,data_Ba_c2])  #插入人看过的数据
#     train_data4 = np.row_stack([train_data,data_Bw_c2])  #插入人看过且机器分类错误的数据
# 
#     test_data_error4 = np.row_stack([data_B_e2,data_Bn_e2])
#     test_data4 = np.row_stack([data_B_c2,data_Bn_c2])
# 
#     # 重新训练模型
#     model_path4 = "E:\\code\\bayes-python\\act\\model\\M_t" + str(ite+1) + ".pkl"
#     M4 = SC.model_train(features, labels, data=train_data4, model_path=model_path4, continuous=continuous)
#     classical_P4,classical_BvSB4 = SC.classify_tuples(test_data_error4, M4, labels)
#     
#     data_Bu_l4,data_Bu_e4,data_Bu_c4,data_Bn_l4,data_Bn_e4,data_Bn_c4,data_Bw_c4\
#         =get_ite_data2(classical_BvSB4,test_data_error4,test_data4,labels,model=1)
#     data_Pu_l4,data_Pu_e4,data_Pu_c4,data_Pn_l4,data_Pn_e4,data_Pn_c4\
#         =get_ite_data2(classical_P4,test_data_error4,test_data4,labels,model=2)
#         
#     count22, sum_update22, sum_error22 = evaluate3(data_Bu_l4,data_Bu_e4,data_Bu_c4, labels)
#     count42, sum_update42, sum_error42 = evaluate3(data_Pu_l4,data_Pu_e4,data_Pu_c4, labels)
#     count52, sum_update52, sum_error52 = evaluate3(data_Bn_l4,data_Bn_e4,data_Bn_c4,labels)
#     count62, sum_update62, sum_error62 = evaluate3(data_Pn_l4,data_Pn_e4,data_Pn_c4,labels)
#     count_B2 = sum_error12 + count22
#     sum_update_B2 = sum_error12 + sum_update22
#     sum_error_B2 = sum_error12 + sum_error22 + sum_error52
#     
#     count_P2 = sum_error32 + count42
#     sum_update_P2 = sum_error32 + sum_update42
#     sum_error_P2 = sum_error32 + sum_error42 + sum_error62
#     
#     count_B_M2 = count12 + count22
#     sum_update_B_M2 = sum_update12 + sum_update22
#     count_P_M2 = count32 + count42
#     sum_update_P_M2 = sum_update32 + sum_update42
# #    print('actB: precision:{}\t recall:{}\n actP: precision:{}\t recall:{}\nsum_errorB:{}\nsum_errorP:{}'.format(count_B2/sum_update_B2,count_B2/sum_error_B2,count_P2/sum_update_P2,count_P2/sum_error_P2,sum_error_B2,sum_error_P2))
# #    print('count5:{}\ncount6:{}\nupdate5:{}\nupdate6:{}\nsum_error5:{}\nsum_error6:{}\n'.format(count52,count62,sum_update52,sum_update62,sum_error52,sum_error62))
# #    print('not-act: precision:{}\n recall:{}'.format(count/sum_update,count/sum_error))
# # 评价指标计算 精度、回归率、数据质量
#     # 人+机器参与
#     precision_B_R4.append(count_B2/sum_update_B2) 
#     precision_P_R4.append(count_P2/sum_update_P2)
#     recall_B_R4.append(count_B2/sum_error_B2)
#     recall_P_R4.append(count_P2/sum_error_P2)
#     data_quality_B_R4.append(1-(sum_error22-2*count22+sum_update22+sum_error52)/len(classical_BvSB2)/len(labels))
#     data_quality_P_R4.append(1-(sum_error42-2*count42+sum_update42+sum_error62)/len(classical_P2)/len(labels))
# #    Line2(precision_B2,precision_B_M2,precision_B_R4,title="ACT+ML+retrain+test",model=7)
# #    Line2(recall_B2,recall_B_M2,recall_B_R4,title="ACT+ML+retrain+test",model=8)
# #    Line2(data_quality_B2,data_quality_B_M2,data_quality2,data_quality_B_R4,title="ACT+ML+retrain+test",model=9)
#     return SCAREd_tuples(ite+1)
# 
# =============================================================================

if __name__ == '__main__':
    # 参数
    print('开始')
    begin_time = time.clock()
    
    continuous = [0,1,2,5]
    features = [0,1,2,3,4,5,6,7,8,9,10,11]
    labels = [12,13,14]
    
# =============================================================================
#     continuous = []
#     features = [0,1,3]
#     labels = [2,4]
#     
# =============================================================================
#    block_features = [6,8,10,11]
    # 导入类
    BC = BayesClassical()
    SC = SCAREd()
    # 计算参数
    SC.parameter2(features, labels)
    # 多分类属性分类
#    count = 0
#    sum_update = 0
#    sum_error = 0
    ite()
# =============================================================================
#     people_effort = []
#     people_effort2 = []
# 
#     precision_B = []
#     precision_P = []
#     precision_B_M = []
#     precision_P_M = []
#     precision_B2 = []
#     precision_P2 = []
#     precision_B_M2 = []
#     precision_P_M2 = []
#     precision_B_R = []
#     precision_P_R = []
#     precision_B_R4 = []
#     precision_P_R4 = []
# 
#     recall_B = []
#     recall_P = []
#     recall_B_M = []
#     recall_P_M = []
#     recall_B2 = []
#     recall_P2 = []
#     recall_B_M2 = []
#     recall_P_M2 = []
#     recall_B_R = []
#     recall_P_R = []
#     recall_B_R4 = []
#     recall_P_R4 = []
# 
#     count_B = []
#     count_P = []
#     count_B2 = []
#     count_P2 = []
#     
#     data_quality_B = []
#     data_quality_P = []
#     data_quality_B_M = []
#     data_quality_P_M = []
#     data_quality_B2 = []
#     data_quality_P2 = []
#     data_quality_B_M2 = []
#     data_quality_P_M2 = []
#     data_quality_B_R = []
#     data_quality_P_R = []
#     data_quality_B_R4 = []
#     data_quality_P_R4 = []
#     data_quality = []
#     data_quality2 = []
#     data_quality_ALL = []
#     data_quality_B_ALL = []
#     data_quality_B_M_ALL = []
#     
#     update = []
#     length = []
#     data_quality_B_ALL_not = []
#     data_quality_B_M_ALL_not = []
#     data_quality_ALL_not = []
#     
#     a1 = []
#     a2 = []
#     b1 = []
#     b2 = []
# =============================================================================
#    SCAREd_tuples(1,count,sum_update,sum_error)
#    SCAREd_tuples(0)
    # 水平划分 + 多分类
#    SCAREd_block()
    end_time = time.clock()
    print(end_time - begin_time)

    '''
    [0,   1   2   3    4   5   6  7   8  9  10 11 12 13]
    [[], [], [], 119, 92, [], 9, 16, 7, 15, 6, 5, 2, 42]
    # 导入训练集
    train_path = "E:\\code\\bayes-python\\adult\\adult_train_1.csv"
    train_data = load_data(train_path)
    X, Y = divide_XY(train_data, features, labels)
    # 水平划分
#    data_block = SC.block(train_data, continuous=continuous)
    # 训练+存储模型
#    P_y, P_xy = BC.bayes_model(X, Y, continuous)
#    model_path = "E:\\code\\bayes-python\\model\\P.pkl"
#    BC.save_model(P_y, P_xy, model_path)
    # 导入模型
#    M = BC.load_model(model_path)
    M = SC.model_train(features, labels, data=train_data, continuous=continuous)
    # 测试
    test_path = "E:\\code\\bayes-python\\adult\\adult_test_1.csv"
    test_data = load_data(test_path)
    classical = SC.classify_tuples(test_data, M, labels)
    evaluate(classical, test_data, labels)
    X, Y = divide_XY(test_data, features, labels)
    features_ = features.copy()
    classical2 = {}
    for i in labels:
        print(i)
        label = [i]
        X, Y = divide_XY(test_data, features_, label)
        P_yx, classical2[i] = BC.classical(X, M=M[i])
        features_.append(i)
    # 评估
    sum_1 = 0
    count1 = 0
    for i in labels:
        a, b = evaluate2(classical2, test_data, i)
        count1 += a
        sum_1 += b
    print('总准确度',count1/sum_1)
    end_time = time.clock()
    print(end_time - begin_time)
'''