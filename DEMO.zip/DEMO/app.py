from decorator import append
from flask import Flask, render_template,redirect,url_for
import pandas as pd
import numpy as np
from ADC import *

class Data(object):
    def __init__(self,data,index,size,data_pre,data_repair,data_contain,features,labels):
        self.data = data
        self.index = index
        self.size = size
        self.data_pre = data_pre
        self.data_repair = data_repair
        self.data_contain = data_contain
        self.features = features
        self.labels =labels


app = Flask(__name__)

@app.before_first_request
def ready():
    return 0

@app.route('/')
def root_page():
    hello_world = 'hello_world'
    return render_template('root_page.html')
    return redirect(url_for('hello_world',hello_world=hello_world))

@app.route('/repair/<raw>/<operate>/<list>')
def repair(raw=-1,operate='-1',list=[]):
    if operate == '-1':
        data_path = "E:\\code\\bayes-python\\act\\train_data\\train_data0.csv"
        data = pd.read_csv(data_path)
        # index = data.keys()
        index = ['age','fnlwgt','education-num','capital-gain','capital-loss','hours-per-week','workclass','education',
                 'marital-status','occupation','relationship','race','sex','native-country','income']
        size = data.shape
        features = [0, 1, 2, 3, 4, 5, 6, 7, 8]
        labels = [i for i in range(data.shape[1]) if i not in features]
        data_pre = data[data.keys()[features]]
        data_repair = data[data.keys()[labels]]
        data_contain = data[data.keys()[labels]]
        D = Data(data,index,size,data_pre,data_repair,data_contain,features,labels)
        #1. 初始数据显示
        return render_template('repair.html', Data=D)
    elif operate == '0':
        #2. 删除index2对应数据
        return render_template('repair.html')
    elif operate == '1':
        #3. 存储选择的数据，并删除对应的数据
        print(Data.data_pre[:2])
        return redirect('hello_world/000')


@app.route('/hello_world/<hello_world>')
def hello_world(hello_world):
    return hello_world
    print(c)
    a = [1, 2, 3, 4]
    a = c
    b = pd.DataFrame(a)
    b = np.array(a)
    print(a)
    print(b)
    return render_template('test.html', a=a, b=b)


if __name__ == '__main__':
    app.run(port=5001)








