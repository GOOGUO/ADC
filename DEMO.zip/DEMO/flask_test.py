"""
分三部分：
1.数据处理
2.传参到前台
3.接收前台传参
"""

#包准备和参数准备
#import pandas as pd
from builtins import print

from ADC import *
from flask import Flask,render_template, request, redirect
app = Flask(__name__)


@app.route('/')
def test():

    return render_template('test.html')
#修复界面
'''
@app.route('/repair',methods=['GET'])
def index():
    """
    1.数据准备
    2.逻辑
    3.参数传递
    """
    return render_template('gky.html')
'''
@app.route('/user/<name>')
def user(name):
    return 'name %s'%name

if __name__ == '__main__':

    app.run()
    print(3)