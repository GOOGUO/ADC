from flask import Flask, render_template, redirect, url_for
from func.ADC import *
from func.inputdata import getdata
from func.inputdata import dropdata

# from entry.entry import Data


app = Flask(__name__)

Data = None
Data_clean = pd.DataFrame()
Data_dirty = pd.DataFrame()


# ite = 0     #每一轮修复、进行到第几组展示

@app.before_first_request
def ready():
    return 0


"""
    *初始页面
    *装载数据 + 开始
"""


@app.route('/')
def root_page():
    # hello_world = 'hello_world'
    return render_template('root_page_test.html')
    # return redirect(url_for('hello_world',hello_world=hello_world))


"""
    *展示第ite轮数据，用于用户清洗数据
"""


@app.route('/ADC/<ite>')
def show(ite):
    global Data
    ite = int(ite)
    if (Data is None):
        data_path1 = "data\\test_data_error" + str(ite) + ".csv"
        data_path2 = "data\\test_data" + str(ite) + ".csv"
        Data = getdata(data_path1, data_path2)
    # print(ite)
    # print(Data.data_pre)
    return render_template("repair.html", Data=Data, ite=ite)


"""
    *确认修复
    *保存修复干净的数据+去除修复过的数据用于展示
"""


@app.route('/ADC/confirm/<ite>/<index>')
def confirm(ite, index):
    global Data
    global Data_clean
    ite = int(ite)
    index = int(index)

    data_clean = Data.data.loc[index]
    Data_clean = Data_clean.append(data_clean)

    Data = dropdata(Data, index)
    return render_template("repair.html", Data=Data, ite=ite)


"""
    *不可判断
    *从页面去除不可判断的数据 + 保存为最终待清洗数据
"""


@app.route('/ADC/delete/<ite>/<index>')
def delete(ite, index):
    global Data
    global Data_dirty
    ite = int(ite)
    index = int(index)

    data_dirty = Data.data.loc[index]
    Data_dirty = Data_dirty.append(data_dirty)

    Data = dropdata(Data, index)
    return render_template("repair.html", Data=Data, ite=ite)

"""
    *结束这一组数据清洗+转到下一组数据
    *保存剩下的脏数据+准备下一个数据（show(ite+1)）
"""


@app.route('/ADC/next/<ite>')
def next(ite):
    global Data
    global Data_dirty
    ite = int(ite)

    Data_dirty = Data_dirty.append(Data.data)

    Data = None
    return show(ite)


@app.route('/repair/<raw>/<operate>/<list>')
# def repair(raw=-1,operate='-1',list=[]):
# if operate == '-1':
#     data_path = "E:\\code\\bayes-python\\act\\train_data\\train_data0.csv"
#     Data = getdata(data_path)
#     #1. 初始数据显示
#     return render_template('repair.html', Data=Data)
# elif operate == '0':
#     #2. 删除index2对应数据
#     return render_template('repair.html')
# elif operate == '1':
#     #3. 存储选择的数据，并删除对应的数据
#     print(Data.data_pre[:2])
#     return redirect('hello_world/000')

@app.route('/hello_world/<hello_world>')
def hello_world(hello_world):
    return hello_world
    print(c)
    a = [1, 2, 3, 4]
    a = c
    b = pd.DataFrame(a)
    b = np.array(a)
    print(a)
    print(b)
    return render_template('test.html', a=a, b=b)


if __name__ == '__main__':
    app.run(port=5001)
